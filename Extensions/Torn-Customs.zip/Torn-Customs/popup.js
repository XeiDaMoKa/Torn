// Object to store the user's custom settings.
// This will keep track of things like colors and visibility settings.
let customData = {};

// Function to load saved settings from Chrome's local storage.
// This retrieves any previously saved settings and applies them to the extension.
function loadSettings() {
    chrome.storage.local.get('customSettings', function(data) {
        // If there are saved custom settings, update the customData object and apply them.
        if (data.customSettings) {
            customData = data.customSettings;
            applySettings();  // Applies the settings to the current Torn.com page.
            updateCssText();  // Updates the CSS text to reflect the current settings.
            updateUI();       // Updates the popup UI to show the saved settings.
        }
    });
}

// Function to apply the settings to the current Torn.com page.
// It sends the stored custom data to the content script that runs on Torn.com.
function applySettings() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.sendMessage(tabs[0].id, customData);  // Sends the custom data to the content script.
    });
}

// Function to handle changes to settings.
// Whenever a user updates a setting (like changing a color), this updates the customData object,
// applies the new settings to Torn, and saves them.
function handleSettingChange(key, value) {
    customData[key] = value;  // Update the specific setting (e.g., body background color).
    applySettings();          // Apply the updated settings to the current page.
    saveSettings();           // Save the updated settings to Chrome storage.
    updateCssText();          // Update the CSS text area with the new settings.
}

// Function to save settings to Chrome's local storage.
function saveSettings() {
    chrome.storage.local.set({ customSettings: customData });  // Saves the current customData.
}

// Function to update the popup UI based on the saved settings.
// This will make sure that the color pickers and other controls show the correct values.
function updateUI() {
    // If a background color was saved for the body, set the color picker to that color.
    if (customData['body'] && customData['body'].backgroundColor) {
        $('#bodyColor').val(customData['body'].backgroundColor);
    }
    // If a text color was saved for the titles (h4 elements), set the color picker to that color.
    if (customData['h4'] && customData['h4'].color) {
        $('#titleColor').val(customData['h4'].color);
    }
    // If the area titles were hidden, make sure the checkbox is checked.
    if (customData['.header___RpWar'] && customData['.header___RpWar'].display === 'none') {
        $('#hideAreaTitles').prop('checked', true);
    }
}

// Event listener for the body color picker.
// When the user changes the body background color, it updates the settings and applies them.
$('#bodyColor').on('input', function() {
    handleSettingChange('body', { backgroundColor: this.value });  // Save and apply the new background color.
});

// Event listener for the title text color picker.
// When the user changes the title text color, it updates the settings and applies them.
$('#titleColor').on('input', function() {
    handleSettingChange('h4', { color: this.value });  // Save and apply the new text color.
});

// Event listener for the 'Hide Area Titles' checkbox.
// When the user checks or unchecks this box, it hides or shows the area titles on Torn.
$('#hideAreaTitles').on('change', function() {
    handleSettingChange('.header___RpWar', { display: this.checked ? 'none' : 'block' });  // Show/hide the area titles.
});

// Event listener for the 'Instant Styling' button.
// When clicked, it shows the container where users can copy the generated CSS to apply instantly.
$('#instantStyling').click(function() {
    $('#cssTextContainer').show();  // Shows the CSS text container.
});

// Function to update the CSS text area with the current settings.
// This allows users to copy the CSS and paste it into the customs.css file.
function updateCssText() {
    let cssText = '';  // Initialize an empty string to store the generated CSS.
    // If the body has a background color set, add it to the CSS text.
    if (customData['body'] && customData['body'].backgroundColor) {
        cssText += `body { background-color: ${customData['body'].backgroundColor}; }\n`;
    }
    // If the titles (h4 elements) have a text color set, add it to the CSS text.
    if (customData['h4'] && customData['h4'].color) {
        cssText += `h4 { color: ${customData['h4'].color}; }\n`;
    }
    // If the area titles are hidden, add that to the CSS text.
    if (customData['.header___RpWar']) {
        cssText += `.header___RpWar { display: ${customData['.header___RpWar'].display}; }\n`;
    }
    // Update the CSS text area with the generated CSS.
    $('#cssText').val(cssText);
}

// Event listener for the 'Clear Storage' button.
// When clicked, it clears all stored custom settings, resets the UI, and applies default styles.
$('#clearStorage').click(function() {
    chrome.storage.local.clear(function() {
        alert('Storage has been cleared!');  // Notify the user that storage has been cleared.
        customData = {};                     // Reset the customData object.
        $('#cssText').val('');               // Clear the CSS text area.
        applySettings();                     // Apply the default styles.
        updateCssText();                     // Update the CSS text area with no settings.
        updateUI();                          // Reset the UI to its default state.
    });
});

// Event listener for the 'Copy CSS' button.
// When clicked, it copies the generated CSS text to the user's clipboard.
$('#copyCss').click(function() {
    navigator.clipboard.writeText($('#cssText').val()).then(
        () => alert('CSS copied to clipboard!'),  // Notify the user that CSS has been copied.
        (err) => alert('Error copying CSS: ' + err)  // If there was an error, display it.
    );
});

// When the popup loads, this runs to initialize the settings and UI.
// It makes sure the popup reflects any saved settings when the user opens it.
$(document).ready(function() {
    loadSettings();  // Load any saved settings from Chrome's local storage.
});
